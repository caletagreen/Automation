import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LocationTracker } from '../../providers/location-tracker';
import {Http, Headers } from '@angular/http';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  api_key = '';

  constructor(public http:Http, public navCtrl: NavController, public locationTracker: LocationTracker) {
    
  }
 
  start(){
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    let data=JSON.stringify({api_key: this.api_key});
    this.http.post('http://m2mlight.com/iot/track_login.php',data,headers)
    .map(res => res.json())
    .subscribe(res => {
      if (res == "fail"){
        alert("api_key is not valid")
      } else if (res == "access"){
        alert("Start tracking now");
        this.locationTracker.startTracking(this.api_key);       
      }
    }, (err) => {
      alert("Failed");
    });
  }
 
  stop(){
    alert("Stop tracking now");
    this.locationTracker.stopTracking();
  }


}
